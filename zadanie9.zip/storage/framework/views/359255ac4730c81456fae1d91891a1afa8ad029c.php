    <li class="nav-item"><a class="nav-link" href="<?= route('home') ?>">Сайт</a></li>
    <li class="nav-item"><a class="nav-link <?php echo e(request()->routeIs('admin.index')?'active':''); ?>" href="<?= route('admin.index') ?>">Админка</a></li>

    <li class="nav-item"><a class="nav-link <?php echo e(request()->routeIs('admin.page3')?'active':''); ?>" href="<?= route('admin.page3') ?>">Скачать изображение</a></li>
    <li class="nav-item dropdown">
        <a class="nav-link dropdown-toggle" href="#" id="navbarDarkDropdownMenuLink" role="button" data-bs-toggle="dropdown" aria-expanded="false">
            Скачать текст
        </a>
        <ul class="dropdown-menu dropdown-menu-light" aria-labelledby="navbarDarkDropdownMenuLink">
            <li class="nav-item"><a class="nav-link <?php echo e(request()->routeIs('admin.page2')?'active':''); ?>" href="<?= route('admin.page2') ?>">Скачать все новости</a></li>
            <?php $__empty_1 = true; $__currentLoopData = $all_categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category_item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>

            <li><a class="dropdown-item" href="<?php echo e(route('admin.download',$category_item['id'] )); ?>">Скачать новости "<?php echo e($category_item['title']); ?>"</a></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <li><a class="dropdown-item" href="#">Нет категорий</a></li>
            <?php endif; ?>

        </ul>
    </li>


    <li class="nav-item dropdown">
        <a class="nav-link dropdown-toggle" href="#" id="navbarDarkDropdownMenuLink1" role="button" data-bs-toggle="dropdown" aria-expanded="false">
            Редактировать
        </a>
        <ul class="dropdown-menu dropdown-menu-light" aria-labelledby="navbarDarkDropdownMenuLink1">
            <li><a class="dropdown-item" href="<?php echo e(route('news.index')); ?>">Редактировать новости</a></li>
            <li><a class="dropdown-item" href="<?php echo e(route('categories.index')); ?>">Редактировать категории</a></li>
            <li><a class="dropdown-item" href="<?php echo e(route('users.index')); ?>">Редактировать пользователей</a></li>
            <li><a class="dropdown-item" href="<?php echo e(route('sources.index')); ?>">Редактировать источники</a></li>
        </ul>
    </li>


    <li class="nav-item dropdown">
        <a class="nav-link dropdown-toggle" href="#" id="navbarDarkDropdownMenuLink2" role="button" data-bs-toggle="dropdown" aria-expanded="false">
            Создать
        </a>
        <ul class="dropdown-menu dropdown-menu-light" aria-labelledby="navbarDarkDropdownMenuLink2">
            <li><a class="dropdown-item <?php echo e(request()->routeIs('news.create')?'active':''); ?>" href="<?= route('news.create') ?>">Создать новость</a></li>
            <li><a class="dropdown-item <?php echo e(request()->routeIs('categories.create')?'active':''); ?>" href="<?php echo e(route('categories.create')); ?>">Создать категорию</a></li>
            <li><a class="dropdown-item <?php echo e(request()->routeIs('users.create')?'active':''); ?>" href="<?= route('users.create') ?>">Создать пользователя</a></li>
            <li><a class="dropdown-item <?php echo e(request()->routeIs('sources.create')?'active':''); ?>" href="<?= route('sources.create') ?>">Создать источник</a></li>
        </ul>
    </li>

    <li class="nav-item"><a class="nav-link" href="<?= route('parser.index') ?>">Парсер</a></li><?php /**PATH E:\PROGRAM\OpenServer\domains\kurslaravel1.local\resources\views/admin/components/menu.blade.php ENDPATH**/ ?>