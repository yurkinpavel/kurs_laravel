<li class="nav-item"><a class="nav-link <?php echo e(request()->routeIs('home')?'active':''); ?>" href="<?php echo e(route('home')); ?>">Главная</a></li>
<li class="nav-item"><a class="nav-link <?php echo e(request()->routeIs('news')?'active':''); ?>" href="<?php echo e(route('news')); ?>">Новости</a></li>
<li class="nav-item"><a class="nav-link <?php echo e(request()->routeIs('categories')?'active':''); ?>" href="<?php echo e(route('categories')); ?>">Новости по категориям</a></li>
<li class="nav-item"><a class="nav-link <?php echo e(request()->routeIs('about')?'active':''); ?>" href="<?php echo e(route('about')); ?>">О нас</a></li>
<?php if(!empty(Auth::user())): ?>
<?php if(Auth::user()->is_admin): ?>
<li class="nav-item"><a class="nav-link <?php echo e(request()->routeIs('admin.index')?'active':''); ?>" href="<?php echo e(route('admin.index')); ?>">Админка</a></li>
<?php endif; ?>
<?php endif; ?>                
 <?php /**PATH E:\PROGRAM\OpenServer\domains\kurslaravel1.local\resources\views/components/menu.blade.php ENDPATH**/ ?>