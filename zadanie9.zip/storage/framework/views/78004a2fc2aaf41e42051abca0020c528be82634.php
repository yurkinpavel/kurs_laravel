

<?php
$title='Редактировать источник'
?>

<?php $__env->startSection('title'); ?>
<?php echo e($title); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('header'); ?>
<h1 class="display-4 text-center"><?php echo e($title); ?></h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('menu'); ?>
<?php echo $__env->make('admin.components.menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>
 
<?php $__env->startSection('content'); ?>
<?php if($source): ?>
<div class="container">
<?php echo $__env->make('admin.components.error', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?> 
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-body">
                    <form method="POST" action="<?php echo e(route('sources.update', ['source' => $source['id']])); ?>">
                    <input type="hidden" name="_method" value="PUT">
                        <?php echo csrf_field(); ?>
                        <div class="mb-3">
                            <label for="title" class="form-label">Название источника</label>
                            <input type="text" class="form-control" id="title" name="title" placeholder="Название источника" require="true" value="<?php echo e($source['title']); ?>">
                        </div>

                        <div class="mb-3">
                            <label for="category_id" class="form-label">Категория</label>
                            <select name="category_id" id="category_id" class="form-control">
                                <?php $__empty_1 = true; $__currentLoopData = $all_categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category_item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <option value="<?php echo e($category_item['id']); ?>"  <?php if($source['category_id'] == $category_item['id']): ?> selected <?php endif; ?>><?php echo e($category_item['title']); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <option value="0">Нет категорий</option>
                                <?php endif; ?>
                            </select>

                        </div>

                        <div class="mb-3">
                            <label for="url_source" class="form-label">URL</label>
                            <input type="text" class="form-control" id="url_source" name="url_source" placeholder="URL источника" require="true" value="<?php echo e($source['url_source']); ?>">
                        </div>

                        <div class="col-12">
                             <input name="id" type="hidden" value="<?php echo e($source['id']); ?>">
                            <button type="submit" class="btn btn-primary">Сохранить источник</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<?php else: ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
<h3>Такой новости не существует</h3>
        </div>
    </div>
</div>
<?php endif; ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('footer'); ?>
<?php echo $__env->make('components.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\PROGRAM\OpenServer\domains\kurslaravel1.local\resources\views/admin/edit/editsource.blade.php ENDPATH**/ ?>