

<?php
$title='Редактировать новость'
?>

<?php $__env->startSection('title'); ?>
<?php echo e($title); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('header'); ?>
<h1 class="display-4 text-center"><?php echo e($title); ?></h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('menu'); ?>
<?php echo $__env->make('admin.components.menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>
 
<?php $__env->startSection('content'); ?>
<?php if($news): ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-body">
                    <form method="POST" action="<?php echo e(route('admin.update_news')); ?>">
                        <?php echo csrf_field(); ?>
                        <div class="mb-3">
                            <label for="title_news" class="form-label">Заголовок новости</label>
                            <input type="text" class="form-control" id="title_news" name="title_news" placeholder="Заголовок новости" require="true" value="<?php echo e($news['title']); ?>">
                        </div>

                        <div class="mb-3">
                            <label for="news_category" class="form-label">Категория новости</label>
                            <select name="news_category" id="news_category" class="form-control">
                                <?php $__empty_1 = true; $__currentLoopData = $all_categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category_item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <option value="<?php echo e($category_item['id']); ?>"  <?php if($news['category_id'] == $category_item['id']): ?> selected <?php endif; ?>><?php echo e($category_item['title']); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <option value="0">Нет категорий</option>
                                <?php endif; ?>
                            </select>

                        </div>



                        <div class="mb-3">
                            <label for="short_discraption" class="form-label">Краткое описаниние новости</label>
                            <textarea class="form-control" id="short_discraptiont" name="short_discraption" rows="3" placeholder="Краткое описаниние новости" require="true"><?php echo e($news['short_discraption']); ?></textarea>
                        </div>

                        <div class="mb-3">
                            <label for="full_news" class="form-label">Полное описаниние новости</label>
                            <textarea class="form-control" id="full_news" name="full_news" rows="10" placeholder="Полное описаниние новости" require="true"><?php echo e($news['text']); ?></textarea>
                        </div>

                        
                        <div class="mb-3">
                            <input type="checkbox" class="form-check-input" id="is_private" name="is_private" value="1"  <?php if($news['is_private'] === '1'): ?> checked <?php endif; ?>>
                            <label for="is_private" class="form-label mx-2">Приватная новость</label>
                        </div>

                        <div class="col-12">
                             <input name="edit_id" type="hidden" value="<?php echo e($news['id']); ?>">
                            <button type="submit" class="btn btn-primary">Сохранить новость</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<?php else: ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
<h3>Такой новости не существует</h3>
        </div>
    </div>
</div>
<?php endif; ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('footer'); ?>
<?php echo $__env->make('components.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\PROGRAM\OpenServer\domains\kurslaravel1.local\resources\views/admin/editnews.blade.php ENDPATH**/ ?>