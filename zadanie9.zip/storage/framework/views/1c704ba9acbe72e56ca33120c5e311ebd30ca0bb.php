

<?php
$title='Создать пользователя'
?>

<?php $__env->startSection('title'); ?>
<?php echo e($title); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('header'); ?>
<h1 class="display-4 text-center"><?php echo e($title); ?></h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('menu'); ?>
<?php echo $__env->make('admin.components.menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="container">

<?php echo $__env->make('admin.components.error', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?> 

<div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-body">
                    <form method="POST" action="<?php echo e(route('users.create')); ?>">
                    <input type="hidden" name="_method" value="HEAD">
                        <?php echo csrf_field(); ?>
                        <div class="mb-3">
                            <label for="name" class="form-label">Имя</label>
                            <input type="text" class="form-control" id="name" name="name" placeholder="Имя" require="true" value="<?php echo e(old('name')); ?>">
                        </div>

                        <div class="mb-3">
                            <label for="email" class="form-label">E-mail</label>
                            <input type="email" class="form-control" id="email" name="email" placeholder="E-mail" require="true" value="<?php echo e(old('email')); ?>">
                        </div>

                        <div class="mb-3">
                            <label for="password" class="form-label">Пароль</label>
                            <input type="password" class="form-control" id="password" name="password" placeholder="Пароль" require="true" value="">
                        </div>

   
                        <div class="mb-3">
                            <label for="password_confirmation" class="form-label">Подтвердить пароль</label>
                            <input type="password" class="form-control" id="password_confirmation" name="password_confirmation" placeholder="Подтвердить пароль" require="true" value="">
                        </div>

   
                        <div class="mb-3">
                            <input type="checkbox" class="form-check-input" id="is_admin" name="is_admin" value="1">
                            <label for="is_private" class="form-label mx-2">Админ</label>
                        </div>

                        <div class="col-12">
                            <button type="submit" class="btn btn-primary">Создать пользователя</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>

</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('footer'); ?>
<?php echo $__env->make('components.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\PROGRAM\OpenServer\domains\kurslaravel1.local\resources\views/admin/users/create.blade.php ENDPATH**/ ?>