<div class="alert alert-danger"  style="margin: 20px auto; width:80vw;">
<?php $__currentLoopData = $errors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<p style="margin: 10px 20px"><?php echo e($error); ?></p>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div><?php /**PATH E:\PROGRAM\OpenServer\domains\kurslaravel1.local\resources\views/admin/components/errors.blade.php ENDPATH**/ ?>