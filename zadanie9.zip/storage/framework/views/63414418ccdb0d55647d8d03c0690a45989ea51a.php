

<?php 
$title='404'
?>

<?php $__env->startSection('title'); ?>
<?php echo e($title); ?>

<?php $__env->stopSection(); ?>


<?php $__env->startSection('header'); ?>
<h1 class="text-center"><?php echo e($title); ?></h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('menu'); ?>
<?php echo $__env->make('components.menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="mt-2 p-2 text-center col-6 m-auto  text-dark bg-light ">
    <p class="p-3 mb-2">Страница не найдена. Но у нас есть мого других интересных страниц</p>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('footer'); ?>
<?php echo $__env->make('components.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\PROGRAM\OpenServer\domains\kurslaravel1.local\resources\views/404.blade.php ENDPATH**/ ?>