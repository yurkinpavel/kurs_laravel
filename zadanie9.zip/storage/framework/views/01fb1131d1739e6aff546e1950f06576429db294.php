                <li class="nav-item"><a class="nav-link" href="<?php echo e(route('home')); ?>">Главная</a></li>
                <li class="nav-item"><a class="nav-link" href="<?php echo e(route('news')); ?>">Новости</a><br>
                <li class="nav-item"><a class="nav-link" href="<?php echo e(route('categories')); ?>">Новости по категориям</a></li>
                <li class="nav-item"><a class="nav-link" href="<?php echo e(route('about')); ?>">О нас</a></li>
                <li class="nav-item"><a class="nav-link" href="<?php echo e(route('admin.index')); ?>">Админка</a></li>
 <?php /**PATH E:\PROGRAM\OpenServer\domains\kurslaravel1.local\resources\views/menu.blade.php ENDPATH**/ ?>