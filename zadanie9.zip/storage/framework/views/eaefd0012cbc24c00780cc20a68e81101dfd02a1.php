            <li class="nav-item"><a class="nav-link"  href="<?=route('home')?>">Главная</a></li>
            <li class="nav-item"><a class="nav-link <?php echo e(request()->routeIs('admin.index')?'active':''); ?>"  href="<?=route('admin.index')?>">Админка</a></li>
            <li class="nav-item"><a class="nav-link <?php echo e(request()->routeIs('admin.page2')?'active':''); ?>"  href="<?=route('admin.page2')?>">Страница 2</a></li>
            <li class="nav-item"><a class="nav-link <?php echo e(request()->routeIs('admin.page3')?'active':''); ?>"  href="<?=route('admin.page3')?>">Страница 3</a></li>
            <li class="nav-item"><a class="nav-link <?php echo e(request()->routeIs('addnews')?'active':''); ?>"  href="<?=route('addnews')?>">Добавить новость</a></li>
<?php /**PATH E:\PROGRAM\OpenServer\domains\kurslaravel1.local\resources\views/components/admin/menu.blade.php ENDPATH**/ ?>