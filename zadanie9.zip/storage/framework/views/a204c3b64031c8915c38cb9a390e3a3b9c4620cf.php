

<?php
$title='Агрегатор новостей'
?>

<?php $__env->startSection('title'); ?>
<?php echo e($title); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('header'); ?>
<h1 class="display-4 text-center"><?php echo e($title); ?></h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('menu'); ?>
<?php echo $__env->make('components.menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="mt-2 p-2  col-6 m-auto">

  <div class="card  p-2">
    <img src="/images/no_photo.jpg" class="card-img-top" alt="Laravel">
    <div class="card-body">
      <h5 class="card-title">Тестовое приложение агрегатора новостей</h5>
      <p class="card-text">
      <h3 class="m-b">Чему Вы научитесь</h3>
      <ul class="row m-r-lg">
        <li>Настраивать веб-сервер и разворачивать приложение;</li>
        <li>Понимать шаблон проектирования MVC;</li>
        <li>Понимать структуру и логику фреймворка;</li>
        <li>Проектировать БД и работать с моделями и формами Laravel;</li>
        <li>Использовать расширения и особенности фреймворка;</li>
        <li>Работать с внешними API;</li>
        <li>Придумывать фейковые новости;</li>
      </ul>
      </p>
    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('footer'); ?>
<?php echo $__env->make('components.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\PROGRAM\OpenServer\domains\kurslaravel1.local\resources\views/index.blade.php ENDPATH**/ ?>