<div class="text-center p-3 mb-2 bg-light text-dark d-flex justify-content-around">
<a href="<?=route('home')?>">Главная</a><br>
<a href="<?=route('admin.index')?>">Админка</a><br>
<a href="<?=route('admin.page2')?>">Админка - страница 2</a><br>
<a href="<?=route('admin.page3')?>">Админка - страница 3</a><br>
<a href="<?=route('addnews')?>">Добавить новость</a><br>
</div><?php /**PATH E:\PROGRAM\OpenServer\domains\kurslaravel1.local\resources\views/admin/adminmenu.blade.php ENDPATH**/ ?>